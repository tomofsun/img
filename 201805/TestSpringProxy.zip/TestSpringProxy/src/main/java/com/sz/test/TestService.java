package com.sz.test;

public interface TestService {

	public String sayHello();
}
