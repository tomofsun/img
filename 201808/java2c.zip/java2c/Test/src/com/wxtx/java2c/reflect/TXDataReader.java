package com.wxtx.java2c.reflect;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import com.wxtx.java2c.annotation.TXConvertData;
import com.wxtx.java2c.annotation.TXDataEnum;
import com.wxtx.java2c.converter.TXJava2CUtils;

/**
 * 数据转换
 * @author sun_zeming
 *
 * @param <T>
 */
public class TXDataReader<T> {
	
	private Class<T> clazz;
	/**
	 * 结构体长度
	 */
	private int length;
	/**
	 * 字节对齐长度
	 */
	private int maxTypeLength = 1;
	
	private Map<Integer,TXDataEntiy> dataMap = new  HashMap<Integer,TXDataEntiy>();
	/**
	 * 对齐字节
	 */
	private static byte ALIGN_BYTE = (byte)-52;
	
	public TXDataReader(Class<T> clazz) {
		this.clazz = clazz;
		//读取JavaBean的信息
		init();
		//检查@TXConvertData注解使用是否有误
		check();
		//设置最大对齐字节长度
		initMaxDypeLength();
		//获取JavaBean对应结构体的字节长度
		initDataLength();
	}
	
	/**
	 * 读取JavaBean的信息
	 */
	private void init(){
		// 获取javabean所有的成员变量
		Field[] fields = clazz.getDeclaredFields();
		for(int i=0;i<fields.length;i++){
			// 获取有注解@TXConvertData的成员变量
			TXConvertData dataAnno = fields[i].getAnnotation(TXConvertData.class);
			if(dataAnno == null){
				continue;
			}
			
			TXDataEntiy dataEntity = new TXDataEntiy();
			int index = dataAnno.index();
			//检查@TXConvertData的序号是否有重复问题
			if(dataMap.containsKey(index)){
				throw new RuntimeException("序号重复:"+index);
			}
			//获取数据
			TXDataEnum dataType = dataAnno.dataType();
			fields[i].setAccessible(true);
			int dataSize = dataType.getLength();
			int arraysLength = dataAnno.arrayLength();
			dataEntity.setDataType(dataType);
			dataEntity.setLength(dataSize);
			dataEntity.setField(fields[i]);
			dataEntity.setArraysLength(arraysLength);
			dataMap.put(index, dataEntity);
		}
	}
	
	/**
	 * 检查@TXConvertData注解使用是否有误
	 */
	private void check(){
		for(int i=0;i<dataMap.size();i++){
			TXDataEntiy dataEntity = dataMap.get(i);
			if(dataEntity == null){
				throw new RuntimeException("缺失序号:"+i);
			}
			if(dataEntity.getLength() <0){
				throw new RuntimeException(dataEntity.getDataType().toString()+"字节长度不应小于0");
			}
		}
	}
	
	/**
	 * 设置最大对齐字节长度
	 */
	private void initMaxDypeLength(){
		for(int i=0;i<dataMap.size();i++){
			TXDataEntiy dataEntity = dataMap.get(i);
			if(!isCharType(dataEntity.dataType)){
				if(dataEntity.getDataType().getLength() > maxTypeLength){
					maxTypeLength = dataEntity.getLength();
				}
			}
		}
	}
	
	/**
	 * 获取JavaBean对应结构体的字节长度
	 */
	private void initDataLength(){
		for(int i=0;i<dataMap.size();i++){
			TXDataEntiy dataEntity = dataMap.get(i);
			
			//字节对齐,字节数为结构体内最大长度的整数倍
			if(needAlign(i,length)){
				while(length%maxTypeLength != 0){
					length++;
				}
			}
			
			int arrayLength = dataEntity.getArraysLength();
			if(arrayLength == -1){
				length += dataEntity.getLength();
			} else {
				//数组
				length += dataEntity.getLength()*arrayLength;
			}
		}
	}
	
	/**
	 * 获取JavaBean对应结构体的字节长度
	 */
	public int getDataLength(){
		return length;
	}
	
	/**
	 * Java对象转换为字节数组
	 */
	public byte[] convertToByte(T t) throws Exception{
		byte[] buffer = new byte[length];
		int index = 0;
		for(int i=0;i<dataMap.size();i++){
			TXDataEntiy dataEntity = dataMap.get(i);
			Field field = dataEntity.getField();
			
			byte[] val = getByte(dataEntity, t, field);
			
			//字节对齐,字节数为结构体内最大长度的整数倍
			if(needAlign(i,index)){
				while(index%maxTypeLength != 0){
					buffer[index] = ALIGN_BYTE;
					index++;
				}
			}
			
			System.arraycopy(val, 0, buffer, index, val.length);
			index += val.length;
		}
		return buffer;
	}
	
	/**
	 * 是否需要字节对齐
	 * @return
	 */
	private boolean needAlign(int index,int currentLength){
		if(currentLength%maxTypeLength == 0){
			return false;
		}
		TXDataEnum curDataType = dataMap.get(index).getDataType();
		if((currentLength+curDataType.getLength())%maxTypeLength == 0){
			return false;
		}
		if(currentLength/maxTypeLength == (currentLength+curDataType.getLength())/maxTypeLength){
			return false;
		}
		return true;
	}
	
	private boolean isCharType(TXDataEnum dataType){
		return dataType.equals(TXDataEnum.TXChar);
	}
	/**
	 * 成员变量的值转为字节数组
	 * @param dataEntity
	 * @param t
	 * @param field
	 * @return
	 * @throws Exception
	 */
	private byte[] getByte(TXDataEntiy dataEntity,T t,Field field) throws Exception{
		byte[] val = null;
		int arraysLength = dataEntity.getArraysLength();
		
		if(dataEntity.dataType.equals(TXDataEnum.TXInt)){
			//int
			if(arraysLength != -1){
				//数组
				int[] data = (int[]) field.get(t);
				val = TXJava2CUtils.writeArraysInt(data, arraysLength);
			} else {
				int data = field.getInt(t);
				val = TXJava2CUtils.writeInt(data);
			}
		} else if(dataEntity.dataType.equals(TXDataEnum.TXShortInt)){
			//short
			if(arraysLength != -1){
				//数组
				short[] data = (short[]) field.get(t);
				val = TXJava2CUtils.writeArraysShort(data, arraysLength);
			} else {
				short data = field.getShort(t);
				val = TXJava2CUtils.writeShortInt(data);
			}
		} else if(dataEntity.dataType.equals(TXDataEnum.TXFloat)){
			//float
			if(arraysLength != -1){
				//数组
				float[] data = (float[]) field.get(t);
				val = TXJava2CUtils.writeArraysFloat(data, arraysLength);
			} else {
				float data = field.getFloat(t);
				val = TXJava2CUtils.writeFloat(data);
			}
		} else if(dataEntity.dataType.equals(TXDataEnum.TXChar)){
			//char
			if(arraysLength != -1){
				//数组
				char[] data = (char[]) field.get(t);
				val = TXJava2CUtils.writeArraysChar(data, arraysLength);
			} else {
				char data = field.getChar(t);
				val = TXJava2CUtils.writeChar(data);
			}
		}
		return val;
	}
	
	/**
	 * 字节数组转换为Java对象
	 */
	public T convertToObject(byte[] buffer) throws Exception{
		T result = clazz.newInstance();
		int index = 0;
		for(int i=0;i<dataMap.size();i++){
			TXDataEntiy dataEntity = dataMap.get(i);
			Field field = dataEntity.getField();
			int arraysLength = dataEntity.getArraysLength();
			//获取成员变量对应字节数组长度
			int byteLength = (arraysLength==-1?dataEntity.length:dataEntity.length*arraysLength);
			
			byte[] val = new byte[byteLength];
			
			//字节对齐,字节数为结构体内最大长度的整数倍
			if(needAlign(i,index)){
				while(index%maxTypeLength != 0){
					index++;
				}
			}
			
			System.arraycopy(buffer, index, val, 0, byteLength);
			index += val.length;
			
			setObject(dataEntity, result, field, val);
		}
		return result;
	}
	/**
	 * 字节数组转为Java成员变量
	 * @param dataEntity
	 * @param result
	 * @param field
	 * @param val
	 * @throws Exception
	 */
	private void setObject(TXDataEntiy dataEntity,T result,Field field,byte[] val) throws Exception{
		int arraysLength = dataEntity.getArraysLength();
		
		if(dataEntity.dataType.equals(TXDataEnum.TXInt)){
			//int
			if(arraysLength != -1){
				//数组
				int[] data =  TXJava2CUtils.readArraysInt(val,arraysLength);
				field.set(result, data);
			} else {
				int data = TXJava2CUtils.readInt(val);
				field.setInt(result, data);
			}
		} else if(dataEntity.dataType.equals(TXDataEnum.TXShortInt)){
			//short
			if(arraysLength != -1){
				//数组
				short[] data =  TXJava2CUtils.readArraysShort(val,arraysLength);
				field.set(result, data);
			} else {
				short data = TXJava2CUtils.readShortInt(val);
				field.setShort(result, data);
			}
		} else if(dataEntity.dataType.equals(TXDataEnum.TXFloat)){
			//float
			if(arraysLength != -1){
				//数组
				float[] data =  TXJava2CUtils.readArraysFloat(val,arraysLength);
				field.set(result, data);
			} else {
				float data = TXJava2CUtils.readFloat(val);
				field.setFloat(result, data);
			}
		} else if(dataEntity.dataType.equals(TXDataEnum.TXChar)){
			//char
			if(arraysLength != -1){
				//数组
				char[] data =  TXJava2CUtils.readArraysChar(val,arraysLength);
				field.set(result, data);
			} else {
				char data = TXJava2CUtils.readChar(val);
				field.setChar(result, data);
			}
		}
	}
	
	private class TXDataEntiy{
		private TXDataEnum dataType;
		private int length;
		private Field field;
		private int arraysLength;
		public TXDataEnum getDataType() {
			return dataType;
		}
		public void setDataType(TXDataEnum dataType) {
			this.dataType = dataType;
		}
		public int getLength() {
			return length;
		}
		public void setLength(int length) {
			this.length = length;
		}
		public Field getField() {
			return field;
		}
		public void setField(Field field) {
			this.field = field;
		}
		public int getArraysLength() {
			return arraysLength;
		}
		public void setArraysLength(int arraysLength) {
			this.arraysLength = arraysLength;
		}
	}
}
