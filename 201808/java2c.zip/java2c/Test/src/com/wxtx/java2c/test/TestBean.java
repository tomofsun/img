package com.wxtx.java2c.test;

import com.wxtx.java2c.annotation.TXConvertData;
import com.wxtx.java2c.annotation.TXDataEnum;

public class TestBean {

//	typedef struct Books
//	{
//		char  title[10];
//		char  name;
//		int int_id[2];
//		unsigned short int short_id;
//		float book_id;
//	};
	
	@TXConvertData(index=0,dataType=TXDataEnum.TXChar,arrayLength=10)
	private char[] title;
	@TXConvertData(index=1,dataType=TXDataEnum.TXChar)
	private char name;
	@TXConvertData(index=2,dataType=TXDataEnum.TXInt,arrayLength=2)
	private int[] int_id;
	@TXConvertData(index=3,dataType=TXDataEnum.TXShortInt)
	private short short_id;
	@TXConvertData(index=4,dataType=TXDataEnum.TXFloat)
	private float book_id;
	public char[] getTitle() {
		return title;
	}
	public void setTitle(char[] title) {
		this.title = title;
	}
	public char getName() {
		return name;
	}
	public void setName(char name) {
		this.name = name;
	}
	public int[] getInt_id() {
		return int_id;
	}
	public void setInt_id(int[] int_id) {
		this.int_id = int_id;
	}
	public short getShort_id() {
		return short_id;
	}
	public void setShort_id(short short_id) {
		this.short_id = short_id;
	}
	public float getBook_id() {
		return book_id;
	}
	public void setBook_id(float book_id) {
		this.book_id = book_id;
	}
	
}
