package com.wxtx.java2c.test;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;

import com.wxtx.java2c.reflect.TXDataReader;

public class DoTest {

	public static void main(String[] args) throws Exception {
		
		TXDataReader<TestBean> reader = new TXDataReader<TestBean>(TestBean.class);
		
		SocketAddress address = new InetSocketAddress("127.0.0.1", 8888);
		Socket socket = new Socket();
		socket.connect(address);
		OutputStream out = socket.getOutputStream();
		InputStream in = socket.getInputStream();
		
		TestBean sendData = getBean();
		out.write(reader.convertToByte(sendData));
		byte[] buffer = new byte[reader.getDataLength()];
		in.read(buffer);
		TestBean recv = reader.convertToObject(buffer);
		console(recv);
		out.close();
		socket.close();
	}
	
	private static TestBean getBean(){
		TestBean data = new TestBean();
		data.setTitle(new char[]{'h','e','l','l','o','w','o','r','l',0});
		data.setName('s');
		data.setInt_id(new int[]{123,456});
		data.setShort_id((short)32767);
		data.setBook_id(3.14f);
		return data;
	}
	
	private static void console(TestBean data){
		System.out.println("title:"+new String(data.getTitle()));
		System.out.println("name:"+data.getName());
		System.out.println("short_id:"+data.getShort_id());
		System.out.println("int_id[0]:"+data.getInt_id()[0]);
		System.out.println("int_id[1]:"+data.getInt_id()[1]);
		System.out.println("book_id:"+data.getBook_id());
	}
}
