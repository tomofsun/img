package com.wxtx.java2c.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 需要数据转换的标识注解
 * @author sun_zeming
 *
 */
@Target(ElementType.FIELD)
@Retention(RetentionPolicy.RUNTIME)
public @interface TXConvertData {

	/**
	 * 成员变量在结构体内的序号,以0开始计数
	 */
	int index();
	/**
	 * 成员变量的类型 com.wxtx.java2c.annotation.TXDataEnum
	 */
	TXDataEnum dataType();
	/**
	 * 数组长度,-1则表示非数组
	 * @return
	 */
	int arrayLength() default -1;
}
