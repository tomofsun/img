package com.wxtx.java2c.annotation;

/**
 * 可以转换的数据类型
 * @author sun_zeming
 *
 */
public enum TXDataEnum {

	/**
	 * int
	 */
	TXInt(4),
	/**
	 * short
	 */
	TXShortInt(2),
	/**
	 * char
	 */
	TXChar(1),
	/**
	 * float
	 */
	TXFloat(4)
	;
	private int length;
	private TXDataEnum(int length){
		this.length = length;
	}
	public int getLength(){
		return length;
	}
}
