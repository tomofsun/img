package com.wxtx.java2c.converter;

import com.wxtx.java2c.annotation.TXDataEnum;

/**
 * 数据转换工具
 * @author sun_zeming
 *
 */
public class TXJava2CUtils {

	/**
	 * 字节数组转换为int
	 * @param bArr
	 * @return
	 */
	public static int readInt(byte[] bArr) {
		int dataLength = TXDataEnum.TXInt.getLength();
		int n = 0;
		for(int i=0;i<bArr.length&&i<dataLength;i++){
			int left = i*8;
			int val = (bArr[i]>=0?bArr[i]:256+bArr[i]);
			n+= (val << left);
		}
		return n;
	}
	/**
	 * 字节数组转换为int数组
	 * @param bArr
	 * @param arraysLength 数组长度
	 * @return
	 */
	public static int[] readArraysInt(byte[] bArr,int arraysLength) {
		int[] result = new int[arraysLength];
		int dataLength = TXDataEnum.TXInt.getLength();
		for(int index=0;index<arraysLength;index++){
			int n = 0;
			for(int i=index*dataLength;i<bArr.length&&i<(index+1)*dataLength;i++){
				int left = i*8;
				int val = (bArr[i]>=0?bArr[i]:256+bArr[i]);
				n+= (val << left);
			}
			result[index] = n;
		}
		return result;
	}
	/**
	 * 字节数组转换为short
	 * @param bArr
	 * @return
	 */
	public static short readShortInt(byte[] bArr) {
		int dataLength = TXDataEnum.TXShortInt.getLength();
		short n = 0;
		for(int i=0;i<bArr.length&&i<dataLength;i++){
			int left = i*8;
			int val = (bArr[i]>=0?bArr[i]:256+bArr[i]);
			n+= (val << left);
		}
		return n;
	}
	/**
	 * 字节数组转换为short数组
	 * @param bArr
	 * @param arraysLength 数组长度
	 * @return
	 */
	public static short[] readArraysShort(byte[] bArr,int arraysLength) {
		short[] result = new short[arraysLength];
		int dataLength = TXDataEnum.TXShortInt.getLength();
		for(int index=0;index<arraysLength;index++){
			byte[] buffer = new byte[dataLength];
			for(int i=0;i<dataLength;i++){
				buffer[i] = bArr[index*dataLength+i];
			}
			result[index] = readShortInt(buffer);
		}
		return result;
	}
	/**
	 * 字节数组转换为char
	 * @param bArr
	 * @return
	 */
	public static char readChar(byte[] valArr) {
		return (char)valArr[0];
	}
	/**
	 * 字节数组转换为char数组
	 * @param valArr
	 * @return
	 */
	public static char[] readArraysChar(byte[] valArr,int arraysLength) {
		char[] result = new char[arraysLength];
		int index = 0;
		while(index < valArr.length && index < arraysLength) {
			if(valArr[index] == 0) {
				break;
			}
			result[index] = (char) valArr[index];
			index++;
		}
		return result;
	}
	/**
	 * 字节数组转换为float
	 * @param bArr
	 * @return
	 */
	public static float readFloat(byte[] valArr) {
		int fbit = readInt(valArr);
		return Float.intBitsToFloat(fbit);
	}
	/**
	 * 字节数组转换为float数组
	 * @param bArr
	 * @param arraysLength
	 * @return
	 */
	public static float[] readArraysFloat(byte[] bArr,int arraysLength) {
		float[] result = new float[arraysLength];
		int dataLength = TXDataEnum.TXFloat.getLength();
		for(int index=0;index<arraysLength;index++){
			byte[] tmp = new byte[dataLength];
			System.arraycopy(bArr, index*dataLength, tmp, 0, dataLength);
			result[index] = readFloat(tmp);
		}
		return result;
	}
	/**
	 * int转换为字节数组
	 * @param val
	 * @return
	 */
	public static byte[] writeInt(int val) {
		int dataLength = TXDataEnum.TXInt.getLength();
		byte[] buffer = new byte[dataLength];
		for(int i=0;i<dataLength;i++){
			int left = i*8;
			int tmp = (val>>left)&0xff;
			if(tmp > 127){
				tmp -=256;
			}
			buffer[i] = (byte) tmp;
		}
		return buffer;
	}
	/**
	 * int数组转换为字节数组
	 * @param val
	 * @param arraysLength
	 * @return
	 */
	public static byte[] writeArraysInt(int[] val,int arraysLength) {
		int dataLength = TXDataEnum.TXInt.getLength();
		byte[] buffer = new byte[dataLength*arraysLength];
		for(int i=0;i<val.length;i++){
			System.arraycopy(writeInt(val[i]), 0, buffer, dataLength*i, dataLength);
		}
		return buffer;
	}
	/**
	 * short转换为字节数组
	 * @param val
	 * @return
	 */
	public static byte[] writeShortInt(short val) {
		int dataLength = TXDataEnum.TXShortInt.getLength();
		byte[] buffer = new byte[dataLength];
		for(int i=0;i<dataLength;i++){
			int left = i*8;
			int tmp = (val>>left)&0xff;
			if(tmp > 127){
				tmp -=256;
			}
			buffer[i] = (byte) tmp;
		}
		return buffer;
	}
	/**
	 * short数组转换为字节数组
	 * @param val
	 * @param arraysLength
	 * @return
	 */
	public static byte[] writeArraysShort(short[] val,int arraysLength) {
		int dataLength = TXDataEnum.TXShortInt.getLength();
		byte[] buffer = new byte[dataLength*arraysLength];
		for(int i=0;i<val.length;i++){
			System.arraycopy(writeShortInt(val[i]), 0, buffer, dataLength*i, dataLength);
		}
		return buffer;
	}
	/**
	 * char转换为字节数组
	 * @param val
	 * @return
	 */
	public static byte[] writeChar(char val) {
		byte[] buffer = new byte[1];
		buffer[0] = (byte)val;
		return buffer;
	}
	/**
	 * char转换为字节数组
	 * @param val
	 * @param arraysLength
	 * @return
	 */
	public static byte[] writeArraysChar(char[] val,int arraysLength) {
		int dataLength = TXDataEnum.TXChar.getLength();
		byte[] buffer = new byte[dataLength*arraysLength];
		for(int i=0;i<val.length;i++){
			System.arraycopy(writeChar(val[i]), 0, buffer, dataLength*i, dataLength);
		}
		return buffer;
	}
	/**
	 * float转换为字节数组
	 * @param val
	 * @return
	 */
	public static byte[] writeFloat(float f){
		int fbit = Float.floatToIntBits(f);
		return writeInt(fbit);
	}
	/**
	 * float数组转换为字节数组
	 * @param val
	 * @param arraysLength
	 * @return
	 */
	public static byte[] writeArraysFloat(float[] val,int arraysLength) {
		int dataLength = TXDataEnum.TXFloat.getLength();
		byte[] buffer = new byte[dataLength*arraysLength];
		for(int i=0;i<val.length;i++){
			System.arraycopy(writeFloat(val[i]), 0, buffer, dataLength*i, dataLength);
		}
		return buffer;
	}
}
